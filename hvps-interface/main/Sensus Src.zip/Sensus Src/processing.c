#include "main.h"
#include "stm32f3xx_hal.h"
#include "stdbool.h"
#include "math.h"

#include "processing.h"
#include "control_comm.h"
#include "ext_dacs.h"
#include "io.h"
#include "monitoring.h"

static void set_pwr_cmd(float val);
static void set_kv_cmd(float val);
static void set_fil_cmd(float val);

static void update_config_lock(int32_t password);
static void update_config_val(float val, int32_t idx);


void process_command(int32_t cmd, float param_f, int32_t param_i)
{
	//Ensure float value is valid
	if(isnan(param_f))
	{
		return;
	}

	//Throw error if command besides alive received during emission
	if(sys_stat_check(SYS_EMISSION_ON) && (cmd != CTRL_CMD_ALIVE))
	{
		//TBD TODO throw fault
		//return;
	}

	//Process command here (switch statements)
	switch(cmd)
	{
		case CTRL_CMD_CLEAR_FAULTS:
			//TBD TODO tell faults to clear
			break;
		case CTRL_CMD_SET_PWR:
			set_pwr_cmd(param_f);
			break;
		case CTRL_CMD_SET_KV:
			set_kv_cmd(param_f);
			break;
		case CTRL_CMD_SET_MA_LIM:
			write_ma_lim(param_f);
			break;
		case CTRL_CMD_SET_GRID:
			write_grid(param_f);
			break;
		case CTRL_CMD_SET_FIL:
			set_fil_cmd(param_f);
			break;
		case CTRL_CMD_INTERLOCK_TEST:
			interlock_test(param_i);
			break;
		case CTRL_CMD_CONFIG_PASSWORD:
			update_config_lock(param_i);
			break;
		case CTRL_CMD_SET_CONFIG:
			update_config_val(param_f, param_i);
			break;
		default:
			break;
	}
}

static void set_pwr_cmd(float val)
{
	if(val <= config_vals[SYS_CONFIG_MAX_PWR] && val >= 0)
	{
		set_new_pwr(val);
	}
}

static void set_kv_cmd(float val)
{
	if(val <= config_vals[SYS_CONFIG_MAX_KV] && val >= 0)
	{
		set_new_kv(val);
	}
}

static void set_fil_cmd(float val)
{
	if(val <= config_vals[SYS_CONFIG_FIL_LIM] && val >= 0)
	{
		set_new_fil(val);
	}
}

static void update_config_lock(int32_t password)
{
	if(password == CONFIG_PASSWORD)
	{
		set_sys_bit(SYS_UNLOCKED_CONFIG);
	}
	else
	{
		clear_sys_bit(SYS_UNLOCKED_CONFIG);
	}
}

static void update_config_val(float val, int32_t idx)
{
	if(!sys_stat_check(SYS_UNLOCKED_CONFIG))
	{
		//Do nothing if password is locked
		//return; TBD TODO restore
	}

	//TBD TODO replace with bounds checked switch case below
	if(idx >= 0 && idx < NUM_SYS_CONFIG)
	{
		config_vals[idx] = val;
	}
/*
	switch(idx)
	{
		case SYS_CONFIG_MAX_PWR:
			break;
		case SYS_CONFIG_MAX_KV:
			break;
		case SYS_CONFIG_FIL_INIT:
			break;
		case SYS_CONFIG_FIL_LIM:
			break;
		case SYS_CONFIG_P:
			break;
		case SYS_CONFIG_I:
			break;
		case SYS_CONFIG_D:
			break;
		case SYS_CONFIG_MAX_I_POS:
			break;
		case SYS_CONFIG_MAX_I_NEG:
			break;
		default:
			break;
	}
*/
}
