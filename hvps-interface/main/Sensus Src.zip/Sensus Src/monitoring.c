#include "main.h"
#include "stm32f3xx_hal.h"
#include "stdbool.h"
#include "math.h"

#include "monitoring.h"
#include "adc.h"
#include "control_comm.h"
#include "ext_dacs.h"
#include "io.h"
#include "timers.h"

uint32_t hvps_fault_mask = 0;

uint32_t sys_stat = 0;
uint32_t sys_io_bits = 0;
uint32_t sys_fault_bits = 0;

float fb_vals[NUM_FB];

float config_vals[NUM_SYS_CONFIG];
float setpoints[NUM_SP];
float kv_out = 0;
float fil_out = 0;

uint32_t kv_stability_count = 0;

float fil_adj = 0;
float prev_error = 0;
float acc_error = 0;

float p_term_debug = 0;
float i_term_debug = 0;
float d_term_debug = 0;

static void update_ma_target();
static void process_kv_ramp();
static void process_fil_ramp();
static void update_kv_ramp();
static float get_fil_ramp();
static void run_pid();


void setup_system_monitoring()
{
	//TBD TODO initialize system config values
	config_vals[SYS_CONFIG_MAX_PWR] = 100;
	config_vals[SYS_CONFIG_MIN_KV] = 4;
	config_vals[SYS_CONFIG_KV_BOUND] = 0.3;
	config_vals[SYS_CONFIG_KV_RAMP_FAST] = 1;
	config_vals[SYS_CONFIG_KV_RAMP_SLOW] = 0.1;
	config_vals[SYS_CONFIG_MAX_KV] = 120.1;
	config_vals[SYS_CONFIG_FIL_INIT] = 700;
	config_vals[SYS_CONFIG_FIL_LIM] = 3700;
	config_vals[SYS_CONFIG_P_HARD] = 10;
	config_vals[SYS_CONFIG_D_HARD] = 2;
	config_vals[SYS_CONFIG_P] = 5;
	config_vals[SYS_CONFIG_I] = 2;
	config_vals[SYS_CONFIG_D] = 1;
	config_vals[SYS_CONFIG_MAX_I_POS] = 2;
	config_vals[SYS_CONFIG_MAX_I_NEG] = -0.05;
	config_vals[SYS_CONFIG_MAX_ADJ_POS] = 5;
	config_vals[SYS_CONFIG_MAX_ADJ_NEG] = -5;
	config_vals[SYS_CONFIG_HARD_THRESH_POS] = 0.15;
	config_vals[SYS_CONFIG_HARD_THRESH_NEG] = -0.15;
	config_vals[SYS_CONFIG_P_THRESH_POS] = 0.08;
	config_vals[SYS_CONFIG_P_THRESH_NEG] = -0.08;
	config_vals[SYS_CONFIG_D_THRESH_POS] = 0.01;
	config_vals[SYS_CONFIG_D_THRESH_NEG] = -0.01;
	config_vals[SYS_CONFIG_MA_THRESH] = 1.8;
	config_vals[SYS_CONFIG_RUN_PID] = 1;

	//Initialize set points
	setpoints[SP_PWR] = 50;
	setpoints[SP_KV] = 0;
	setpoints[SP_MA_LIM] = 0;
	setpoints[SP_GRID] = 0;
	setpoints[SP_FIL] = 0;

	hvps_fault_mask = (1 << IN_FIL_CLK_FAULT) | (1 << IN_CAT_ARC) |
			(1 << IN_FAN_FAULT) | (1 << IN_OC_24_FAULT) |
			(1 << IN_MASTER_FAULT) | (1 << IN_OC_HV_FAULT) |
			(1 << IN_TEMP_1_FAULT) | (1 << IN_OC_CAT_FAULT) |
			(1 << IN_TEMP_3_FAULT) | (1 << IN_TEMP_2_FAULT);
}


bool sys_stat_check(uint8_t bitpos)
{
	if(bitpos >= NUM_SYS_BITS)
	{
		return false;
	}
	if((1<<bitpos) & sys_stat)
	{
		return true;
	}
	return false;
}

void set_sys_bit(uint8_t bitpos)
{
	if(bitpos < NUM_SYS_BITS)
	{
		sys_stat |= (1<<bitpos);
	}
}


void clear_sys_bit(uint8_t bitpos)
{
	if(bitpos < NUM_SYS_BITS)
	{
		sys_stat &= ~(1<<bitpos);
	}
}

void report_int_adc_vals(uint16_t *vals)
{
	//TBD TODO NOTE: if filament current is > 4 A kill filament DAC directly, update setpoint and throw fault
	//fb_vals[FB_FIL_A] = (float)(vals[INT_ADC_FIL_A])/819;	//4095 == 3V on ADC pin == 5A
	fb_vals[FB_FIL_A] = (float)(vals[INT_ADC_FIL_A])/455;	//4095 == 3V on ADC pin == 9A, for temporary resistors only
	fb_vals[FB_GRID] = (float)(vals[INT_ADC_GRID])/13.65;	//4095 == 3V on ADC pin == 300V
}

void report_io_state(uint32_t io_bits)
{
	//Calculate which bits are now high
	uint32_t new_sys_io_active = (sys_io_bits ^ io_bits) & io_bits;

	//Calculate which bits are now low
	uint32_t new_sys_io_inactive = (sys_io_bits ^ io_bits) & sys_io_bits;

	//Save all new bits
	sys_io_bits = io_bits;

	//If any new HVPS fault bits are active, throw a fault
	if(new_sys_io_active && (hvps_fault_mask != 0))
	{
		//TBD TODO throw fault, incl setting fault status to ctrl board
	}

	if(new_sys_io_inactive & (1<<IN_HV_INT))
	{
		lock_hv();
	}

	if(new_sys_io_inactive & (1<<IN_GRID_INT))
	{
		lock_grid();
	}

	if(new_sys_io_active & (1<<IN_MASTER_FAULT))
	{
		HAL_GPIO_WritePin(GPIOD, IO_TEST_1_Pin, GPIO_PIN_SET);
	}
	else if(new_sys_io_inactive & (1<<IN_MASTER_FAULT))
	{
		HAL_GPIO_WritePin(GPIOD, IO_TEST_1_Pin, GPIO_PIN_RESET);
	}

	if(new_sys_io_active & (1<<IN_BEAM_CTRL))
	{
		if(sys_stat_check(SYS_HV_CTRL_EN) && sys_stat_check(SYS_GRID_CTRL_EN))
		{
			//enable_grid_clock();
			pid_ms = 100;
			prev_error = 0;
			acc_error = 0;
			set_sys_bit(SYS_EMISSION_ON);
			HAL_GPIO_WritePin(GPIOE, IO_BEAM_ALLOWED_Pin, GPIO_PIN_SET);
		}
		//TBD TODO else throw fault
	}
	else if(new_sys_io_inactive & (1<<IN_BEAM_CTRL))
	{
		clear_sys_bit(SYS_EMISSION_ON);
		HAL_GPIO_WritePin(GPIOE, IO_BEAM_ALLOWED_Pin, GPIO_PIN_RESET);
		//disable_grid_clock();
	}
}

void report_kv_fb(uint32_t kv_fb)
{
	fb_vals[FB_KV] = (float)(kv_fb)/218.45;	//TBD TODO magic number
}

void report_ma_fb(uint32_t ma_fb)
{
	fb_vals[FB_MA] = (float)((ma_fb)/13107.2) + 0.01;
}


void set_new_kv(float kv)
{
	kv_stability_count = 0;

	//Make sure HV interlock is OK
	if(sys_stat_check(SYS_HV_CTRL_EN))
	{
		set_sys_bit(SYS_KV_RAMPING);
		setpoints[SP_KV] = kv;

		update_ma_target();
	}
	else
	{
		setpoints[SP_KV] = 0;
		update_ma_target();
	}
}

void set_new_pwr(float pwr)
{
	setpoints[SP_PWR] = pwr;
	update_ma_target();
}

static void update_ma_target()
{
	if(setpoints[SP_PWR] <= 0 || isnan(setpoints[SP_PWR]) ||
			setpoints[SP_KV] <= 0 || isnan(setpoints[SP_KV]))
	{
		setpoints[SP_MA] = 0;
	}
	else
	{
		setpoints[SP_MA] = setpoints[SP_PWR] / setpoints[SP_KV];
	}

	write_ma_lim(config_vals[SYS_CONFIG_MA_THRESH]);
}

void set_new_fil(float fil)
{
	set_sys_bit(SYS_WARMING);
	setpoints[SP_FIL] = fil;
}

float get_monitored_float_val(uint32_t comm_idx)
{
	float val = 0;

	switch(comm_idx)
	{
		case COMM_PWR_SP:
			//val = setpoints[SP_PWR]; TBD TODO RESTORE
			val = p_term_debug;
			break;
		case COMM_KV_SP:
			//val = setpoints[SP_KV]; TBD TODO RESTORE
			val = i_term_debug;
			break;
		case COMM_MA_LIM_SP:
			//val = setpoints[SP_MA_LIM]; TBD TODO RESTORE
			val = d_term_debug;
			break;
		case COMM_GRID_SP:
			//val = setpoints[SP_GRID]; TBD TODO RESTORE
			val = fil_adj;
			break;
		case COMM_FIL_SP:
			//val = setpoints[SP_FIL]; TBD TODO RESTORE
			val = fil_out;
			break;
		case COMM_FIL_FB:
			val = fb_vals[FB_FIL_A];
			break;
		case COMM_KV_FB:
			val = fb_vals[FB_KV];
			break;
		case COMM_MA_FB:
			val = fb_vals[FB_MA];
			break;
		case COMM_GRID_FB:
			val = fb_vals[FB_GRID];
			break;
		default:
			break;
	}

	return val;
}

uint32_t get_monitored_int_val(uint32_t comm_idx)
{
	uint32_t val = 0;
	switch(comm_idx)
	{
		case COMM_HVPS_STATUS:
			val = sys_stat;
			break;
		case COMM_IO:
			val = sys_io_bits;
			break;
		case COMM_FAULTS_LIST:
			val = sys_fault_bits;
			break;
		default:
			break;
	}
	return val;
}


void process_monitoring()
{
	/*
	 * TBD TODO - not required
	 * unimplemented for now, but in the future could possibly add
	 * comparison of output SP and DAC output feedback readings here
	 * */

	//Only check kV and heater ramps while no emission is ongoing
	if(!sys_stat_check(SYS_EMISSION_ON))
	{
		//Ramp kV every 250 ms
		if(kv_ramp_ms <= 0)
		{
			kv_ramp_ms = 250; //TBD TODO magic number
			process_kv_ramp();
		}

		//Ramp heater every 1000 ms
		if(fil_ramp_ms <= 0)
		{
			fil_ramp_ms = 1000; //TBD TODO magic number
			process_fil_ramp();
		}
	}
	else if(pid_ms <= 0)
	{
		pid_ms = 100;
		run_pid();
	}
}


static void process_kv_ramp()
{
	//Do nothing if no longer ramping
	if(!sys_stat_check(SYS_KV_RAMPING))
	{
		return;
	}

	//Make sure values are valid
	if(kv_out < 0 || isnan(kv_out) || setpoints[SP_KV] < 0 || isnan(setpoints[SP_KV]))
	{
		//If not set kV to 0
		setpoints[SP_KV] = 0;
		kv_out = 0;
		clear_sys_bit(SYS_KV_RAMPING);

		//TBD TODO throw error
	}
	//If setpoint is low just go to 0
	else if(setpoints[SP_KV] < config_vals[SYS_CONFIG_MIN_KV])
	{
		setpoints[SP_KV] = 0;
		kv_out = 0;
		clear_sys_bit(SYS_KV_RAMPING);
	}
	//Otherwise get kv ramp value
	else
	{
		update_kv_ramp();
	}

	//Make sure we do not overshoot setpoint after ramp
	if(kv_out >= config_vals[SYS_CONFIG_MAX_KV])
	{
		kv_out = 0;
		clear_sys_bit(SYS_KV_RAMPING);
		//TBD TODO throw error
	}
	write_kv(kv_out);
}

static void update_kv_ramp()
{
	float kv_err = fb_vals[FB_KV] - setpoints[SP_KV];
	float kv_err_neg = kv_err * -1;

	if(kv_err < config_vals[SYS_CONFIG_KV_BOUND] && kv_err_neg < config_vals[SYS_CONFIG_KV_BOUND])
	{
		if(kv_stability_count++ > 10)
		{
			kv_stability_count = 0;
			clear_sys_bit(SYS_KV_RAMPING);
		}

		return;
	}

	kv_stability_count = 0;

	//If kv is high, simply drop it down
	if(kv_err > (3*config_vals[SYS_CONFIG_KV_BOUND]))
	{
		kv_out = setpoints[SP_KV] * 0.8;
	}
	//Otherwise kV is close, but still too high, decrease slowly
	else if(kv_err > config_vals[SYS_CONFIG_KV_BOUND])
	{
		kv_out -= config_vals[SYS_CONFIG_KV_RAMP_SLOW];
	}
	//If kv is much lower, increase quickly
	else if(kv_err_neg > (2*config_vals[SYS_CONFIG_KV_RAMP_FAST]))
	{
		kv_out += config_vals[SYS_CONFIG_KV_RAMP_FAST];
	}
	//If kv is still too low but close, increase slowly
	else if(kv_err_neg > config_vals[SYS_CONFIG_KV_BOUND])
	{
		kv_out += config_vals[SYS_CONFIG_KV_RAMP_SLOW];
	}
}

static void process_fil_ramp()
{
	//Make sure values are valid
	if(fil_out < 0 || isnan(fil_out) || setpoints[SP_FIL] < 0 || isnan(setpoints[SP_FIL]))
	{
		//If not set heater to 0
		setpoints[SP_FIL] = 0;
		fil_out = 0;
		write_fil_a(fil_out);
		clear_sys_bit(SYS_WARMING);
	}
	//Simply drop heater if setpoint is lower than current
	else if(fil_out > setpoints[SP_FIL])
	{
		fil_out = setpoints[SP_FIL];
		write_fil_a(fil_out);
		clear_sys_bit(SYS_WARMING);
	}
	//Ramp up if current heater is lower than setpoint
	else if(fil_out < setpoints[SP_FIL])
	{
		//If output is lower than initial first step, ramp to initial step
		if(fil_out < config_vals[SYS_CONFIG_FIL_INIT])
		{
			fil_out = config_vals[SYS_CONFIG_FIL_INIT];
		}
		else
		{
			fil_out += get_fil_ramp();
		}


		//Make sure we do not overshoot setpoint after ramp
		if(fil_out >= setpoints[SP_FIL])
		{
			fil_out = setpoints[SP_FIL];
			clear_sys_bit(SYS_WARMING);
		}
		write_fil_a(fil_out);
	}
}

static float get_fil_ramp()
{
	float step_val = 0;

	//TBD TODO magic numbers
	if(fil_out < 2000)
	{
		step_val = 10;
	}
	else if(fil_out < 2500)
	{
		step_val = 5;
	}
	else if(fil_out < 3000)
	{
		step_val = 2;
	}
	else if(fil_out < 3300)
	{
		step_val = 1;
	}
	else
	{
		step_val = 1;
	}
	return step_val;
}

static void run_pid()
{
	if(config_vals[SYS_CONFIG_RUN_PID] == 0)
	{
		return;
	}
	float error = setpoints[SP_MA] - fb_vals[FB_MA];
	float diff_error = error - prev_error;

	float p_term = 0;
	float i_term = 0;
	float d_term = 0;

	bool p_ok = false;
	bool d_ok = false;
	bool hard_ok = false;

	if(error < config_vals[SYS_CONFIG_P_THRESH_POS] && error > config_vals[SYS_CONFIG_P_THRESH_NEG])
	{
		p_ok = true;
	}
	if(diff_error < config_vals[SYS_CONFIG_D_THRESH_POS] && diff_error > config_vals[SYS_CONFIG_D_THRESH_NEG])
	{
		d_ok = true;
	}
	if(error < config_vals[SYS_CONFIG_HARD_THRESH_POS] && error > config_vals[SYS_CONFIG_HARD_THRESH_NEG])
	{
		hard_ok = true;
	}

	if(!hard_ok)
	{
		acc_error = 0;
		p_term = config_vals[SYS_CONFIG_P_HARD] * error;
		p_term_debug = p_term;
		i_term = config_vals[SYS_CONFIG_I] * acc_error;
		i_term_debug = i_term;
		d_term = config_vals[SYS_CONFIG_D_HARD] * diff_error;
		d_term_debug = d_term;
	}
	else if(p_ok && d_ok)
	{
		diff_error = 0;
		acc_error += error;
		if(acc_error > config_vals[SYS_CONFIG_MAX_I_POS])
		{
			acc_error = config_vals[SYS_CONFIG_MAX_I_POS];
		}
		else if(acc_error < config_vals[SYS_CONFIG_MAX_I_NEG])
		{
			acc_error = config_vals[SYS_CONFIG_MAX_I_NEG];
		}
		p_term = config_vals[SYS_CONFIG_P] * error;
		p_term_debug = p_term;
		i_term = config_vals[SYS_CONFIG_I] * acc_error;
		i_term_debug = i_term;
		d_term = config_vals[SYS_CONFIG_D] * diff_error;
		d_term_debug = d_term;
	}
	else
	{
		p_term = config_vals[SYS_CONFIG_P] * error;
		p_term_debug = p_term;
		i_term = config_vals[SYS_CONFIG_I] * acc_error;
		i_term_debug = i_term;
		d_term = config_vals[SYS_CONFIG_D] * diff_error;
		d_term_debug = d_term;
		acc_error = 0;
	}

	prev_error = error;

	fil_adj = p_term + i_term + d_term;
	if(fil_adj > config_vals[SYS_CONFIG_MAX_ADJ_POS])
	{
		fil_adj = config_vals[SYS_CONFIG_MAX_ADJ_POS];
	}
	else if(fil_adj < config_vals[SYS_CONFIG_MAX_ADJ_NEG])
	{
		fil_adj = config_vals[SYS_CONFIG_MAX_ADJ_NEG];
	}

	fil_out += fil_adj;
	if(fil_out > config_vals[SYS_CONFIG_FIL_LIM])
	{
		fil_out = config_vals[SYS_CONFIG_FIL_LIM];
	}
	write_fil_a(fil_out);
}
