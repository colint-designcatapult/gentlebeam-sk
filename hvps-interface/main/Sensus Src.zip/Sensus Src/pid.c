

/*
float target;
float dt;
float pid_output;
float err;
float prev_err;
float integral;
float derivative;
float kp;
float ki;
float kd;
float max_i;
float min_i;
float max_output;
float min_output;


void run_pid()
{
	float ma_fb = (sys_vals[MA_FB_SUM]>>MA_FB_BIT_SHIFT) * MA_FB_SCALE_FACTOR;
	err = target - ma_fb;

	integral += (err * dt);
	if(integral > max_i)
	{
		integral = max_i;
	}
	else if(integral < min_i)
	{
		integral = min_i;
	}

	derivative = (err - prev_err) / dt;
	prev_err = err;
	pid_output = (kp * err) + (ki*integral) + (kd*derivative);
}
 * */
