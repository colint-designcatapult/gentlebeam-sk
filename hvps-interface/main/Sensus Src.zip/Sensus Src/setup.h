#ifndef SETUP_H_
#define SETUP_H_

void run_setup();
void run_loop();


#endif /* SETUP_H_ */
