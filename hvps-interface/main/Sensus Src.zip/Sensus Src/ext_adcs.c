#include "main.h"
#include "stdbool.h"
#include "stm32f3xx_hal.h"

#include "ext_adcs.h"
#include "monitoring.h"
#include "timers.h"

uint8_t kv_rx_buf[3];
uint8_t ma_rx_buf[3];

uint8_t ext_adc_flags;

float kv_sum = 0;
float ma_sum = 0;

uint32_t kv_cir_buf[EXT_ADC_KV_BUF_SIZE];
uint32_t kv_buf_idx = 0;
uint32_t kv_buf_sum = 0;
uint32_t ma_cir_buf[EXT_ADC_MA_BUF_SIZE];
uint32_t ma_buf_idx = 0;
uint32_t ma_buf_sum = 0;

void setup_ext_adcs()
{
	ext_adc_flags = 0;

	//TBD TODO placeholder initial startup delay
	ext_adc_ms = 10;

	//Initialize CS lines
	HAL_GPIO_WritePin(GPIOF, IO_KV_CS_Pin|IO_MA_CS_Pin, GPIO_PIN_SET);

	//Dummy receive to initialize SPI ports
	HAL_SPI_Receive_IT(&hspi1, kv_rx_buf, 3);
	HAL_SPI_Receive_IT(&hspi3, ma_rx_buf, 3);
}

void process_ext_adcs()
{
	if(ext_adc_ms > 0)
	{
		return;
	}

	if(ext_adc_flags == EXT_ADC_DONE)
	{
		uint32_t adc_val = (kv_rx_buf[0] & 0x07);
		adc_val <<= 8;
		adc_val |= kv_rx_buf[1];
		adc_val <<= 8;
		adc_val |= (kv_rx_buf[2] & 0xF8);
		adc_val >>= 3;

		kv_buf_idx++;
		if(kv_buf_idx >= EXT_ADC_KV_BUF_SIZE)
		{
			kv_buf_idx = 0;
		}

		kv_buf_sum -= kv_cir_buf[kv_buf_idx];
		kv_buf_sum += adc_val;
		kv_cir_buf[kv_buf_idx] = adc_val;
		report_kv_fb(kv_buf_sum/EXT_ADC_KV_BUF_SIZE);


		adc_val = (ma_rx_buf[0] & 0x07);
		adc_val <<= 8;
		adc_val |= ma_rx_buf[1];
		adc_val <<= 8;
		adc_val |= (ma_rx_buf[2] & 0xF8);
		adc_val >>= 3;

		ma_buf_idx++;
		if(ma_buf_idx >= EXT_ADC_MA_BUF_SIZE)
		{
			ma_buf_idx = 0;
		}

		ma_buf_sum -= ma_cir_buf[ma_buf_idx];
		ma_buf_sum += adc_val;
		ma_cir_buf[ma_buf_idx] = adc_val;
		report_ma_fb(ma_buf_sum/EXT_ADC_MA_BUF_SIZE);
	}
	else
	{
		HAL_GPIO_WritePin(GPIOF, IO_KV_CS_Pin|IO_MA_CS_Pin, GPIO_PIN_SET);
		//TBD TODO throw fault due to HW issues
	}

	ext_adc_flags = 0;
	HAL_GPIO_WritePin(GPIOF, IO_KV_CS_Pin|IO_MA_CS_Pin, GPIO_PIN_RESET);
	HAL_SPI_Receive_IT(&hspi1, kv_rx_buf, 3);
	HAL_SPI_Receive_IT(&hspi3, ma_rx_buf, 3);
	ext_adc_ms = 2; //TBD TODO placeholder value
}

void update_ext_adcs()
{

}


void ext_kv_rx_done()
{
	HAL_GPIO_WritePin(GPIOF, IO_KV_CS_Pin, GPIO_PIN_SET);
	ext_adc_flags |= EXT_ADC_KV_DONE;
}

void ext_ma_rx_done()
{
	HAL_GPIO_WritePin(GPIOF, IO_MA_CS_Pin, GPIO_PIN_SET);
	ext_adc_flags |= EXT_ADC_MA_DONE;
}
